package com.barclays.bfams.dto;

import org.springframework.stereotype.Component;

@Component
public class CaseDetail {
	private String timestamp;
	private String message;

	public String getTimestamp() {
		return timestamp;
	}

	public void setTimestamp(String timestamp) {
		this.timestamp = timestamp;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	@Override
	public String toString() {
		return "CaseDetail{" + "timestamp=" + timestamp + ", message='" + message + '\'' + '}';
	}
}
