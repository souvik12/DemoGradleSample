package com.barclays.bfams.kafka.consumer;

import org.springframework.cloud.stream.annotation.StreamListener;
import org.springframework.kafka.support.KafkaHeaders;
import org.springframework.messaging.handler.annotation.Header;
import org.springframework.stereotype.Component;

import com.barclays.bfams.dto.CaseDetail;
import com.barclays.bfams.kafka.channel.StreamProcessor;

@Component
public class KafkaListener {

	@StreamListener(StreamProcessor.INPUT)

	public void messageListener(final CaseDetail payload, @Header(KafkaHeaders.CORRELATION_ID) String correlationID,
			@Header(KafkaHeaders.RECEIVED_PARTITION_ID) String partitionID) {
		
		System.out.println("RECEIVED_PARTITION_ID " + partitionID);
		System.out.println("CorrelationID " + correlationID);
		System.out.println("Kafka Listener got message from topic " + payload);

	}

}
