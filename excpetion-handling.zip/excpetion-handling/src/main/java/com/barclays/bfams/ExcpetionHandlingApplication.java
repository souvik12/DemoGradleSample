package com.barclays.bfams;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.stream.annotation.EnableBinding;
import org.springframework.context.annotation.Bean;
import org.springframework.web.client.RestTemplate;

import com.barclays.bfams.kafka.channel.StreamProcessor;

@SpringBootApplication
@EnableBinding(StreamProcessor.class)
public class ExcpetionHandlingApplication{ 

	
	public static void main(String[] args) {
		SpringApplication.run(ExcpetionHandlingApplication.class, args);
	}
	@Bean
	public RestTemplate restTemplate() {
	    return new RestTemplate();
	}

}
