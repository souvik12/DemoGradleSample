package com.barclays.bfams.kafka.consumer;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.stream.annotation.StreamListener;
import org.springframework.kafka.support.KafkaHeaders;
import org.springframework.messaging.handler.annotation.Header;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import com.barclays.bfams.dto.CaseDetails;
import com.barclays.bfams.exception.NonBfaAPIException;
import com.barclays.bfams.kafka.channel.StreamProcessor;
import com.barclays.bfams.kafka.producer.KafkaPublisher;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

@Component
public class KafkaListener {
	@Autowired
	KafkaPublisher kafkaPublisher;

	@Autowired
	private RestTemplate restTemplate;

	private static final Logger logger = LoggerFactory.getLogger(KafkaListener.class);

	@StreamListener(StreamProcessor.INPUT)
	public void messageListener(final CaseDetails payload, @Header(KafkaHeaders.CORRELATION_ID) String correlationID) {
		logger.info("CorrelationID " + correlationID);
		logger.info("Received message from topic " + payload);

		try {
			String message = restTemplate.getForObject("http://localhost:8091/custmer", String.class);
			logger.debug("Rest API call " + message);
			kafkaPublisher.MessagePublisherCustomer(payload);
		} catch (RestClientException e) {
			logger.error(e.getMessage());
			String jsonString = createJsonString(payload);
			
			throw new NonBfaAPIException(jsonString);
		}

	}

	private String createJsonString(final CaseDetails payload) {
		// Java Object to Json.
		ObjectMapper mapper = new ObjectMapper();
		String jsonString = null;
		// Converting the Object to JSONString
		try {
			jsonString = mapper.writeValueAsString(payload);
		} catch (JsonProcessingException e1) {
			
			logger.error("Error while converting DTO to Json String"+e1.getMessage());
		}
		return jsonString;
	}
/*
	@StreamListener("errorChannel")
	public void globalErrors(ErrorMessage message) {
		

		String payload = message.getPayload().getCause().getMessage();
		//System.out.println("jsonString Payload " + payload);
		CaseDetails replayP = null;
		try {
			replayP = new ObjectMapper().readValue(payload, CaseDetails.class);
			System.out.println("replayP " + replayP);

		} catch (JsonParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (JsonMappingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}*/
}
