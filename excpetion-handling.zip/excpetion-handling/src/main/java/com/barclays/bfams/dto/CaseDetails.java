package com.barclays.bfams.dto;

import java.time.Instant;

public class CaseDetails {

	private String statusCode;
	private String accountNumber;
	private String customerIdentifier;
	private String createdByUserID;

	public CaseDetails() {

	}

	public CaseDetails(Long id, String statusCode, String accountNumber, String customerIdentifier,
			String createdByUserID, Instant createdTimestamp, Instant updatedTimestamp) {
		this.statusCode = statusCode;
		this.accountNumber = accountNumber;
		this.customerIdentifier = customerIdentifier;
		this.createdByUserID = createdByUserID;

	}

	public String getStatusCode() {
		return statusCode;
	}

	public void setStatusCode(String statusCode) {
		this.statusCode = statusCode;
	}

	public String getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}

	public String getCustomerIdentifier() {
		return customerIdentifier;
	}

	public void setCustomerIdentifier(String customerIdentifier) {
		this.customerIdentifier = customerIdentifier;
	}

	public String getCreatedByUserID() {
		return createdByUserID;
	}

	public void setCreatedByUserID(String createdByUserID) {
		this.createdByUserID = createdByUserID;
	}

	@Override
	public String toString() {
		return "CaseDetails{" + "statusCode='" + statusCode + '\'' + ", accountNumber='" + accountNumber + '\''
				+ ", customerIdentifier='" + customerIdentifier + '\'' + ", createdByUserID='" + createdByUserID + '\''
				+ '}';
	}
}
