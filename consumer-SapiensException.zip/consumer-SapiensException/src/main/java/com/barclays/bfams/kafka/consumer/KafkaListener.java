package com.barclays.bfams.kafka.consumer;

import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.cloud.stream.annotation.StreamListener;
import org.springframework.kafka.support.KafkaHeaders;
import org.springframework.messaging.handler.annotation.Header;
import org.springframework.stereotype.Component;

import com.barclays.bfams.dto.CaseDetails;
import com.barclays.bfams.exception.BfaSapiensException;
import com.barclays.bfams.kafka.channel.StreamProcessor;
import com.barclays.digital.spndcneng.contact.DetermineContactSteategy;
import com.barclays.digital.spndcneng.excpetion.SapiensException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

@Component
public class KafkaListener {

	private static final Logger logger = LoggerFactory.getLogger(KafkaListener.class);

	@StreamListener(StreamProcessor.INPUT)
	public void messageListener(final CaseDetails payload, @Header(KafkaHeaders.CORRELATION_ID) String correlationID) {
		logger.info("CorrelationID " + correlationID);
		logger.info("Received message from topic " + payload);
		

		DetermineContactSteategy contStrategy = new DetermineContactSteategy();
		Map<String, Object> customerMap = new HashMap<String, Object>();
		try {
			logger.info("Sapiens rule execution. ");
			contStrategy.executeContact(customerMap);
		} catch( SapiensException e) {
			logger.error("Sapiens rule execution ERROR "+e.getMessage());
			String jsonString = createJsonString(payload);
			throw new BfaSapiensException(jsonString);
		}

	}
	
	private String createJsonString(final CaseDetails payload) {
		// Java Object to Json.
		ObjectMapper mapper = new ObjectMapper();
		String jsonString = null;
		// Converting the Object to JSONString
		try {
			jsonString = mapper.writeValueAsString(payload);
		} catch (JsonProcessingException e1) {
			logger.error("Error while converting DTO to Json String" +e1.getMessage());
		}
		return jsonString;
	}
	

	/*@StreamListener("errorChannel")
	public void globalErrors(ErrorMessage message) {

		String payload = message.getPayload().getCause().getMessage();
		System.out.println("jsonString Payload " + payload);
		CaseDetails replayP = null;
		try {
			replayP = new ObjectMapper().readValue(payload, CaseDetails.class);
			System.out.println("replayP " + replayP);

		} catch (JsonParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (JsonMappingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}*/
}
