package com.barclays.bfams.dto;

import java.time.Instant;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Size;

public class CaseDetails {

	private String statusCode;
	@Size(max = 20, min = 10,message = "AccountNumber invalid; size must be between 10 and 20")
    @NotEmpty(message = "Please enter Account Number")
	private String accountNumber;
	@Size(max = 10, min = 5, message = "customerIdentifier invalid; size must be between 5 and 10")
	private String customerIdentifier;
	private String createdByUserID;

	public CaseDetails() {

	}

	public CaseDetails(Long id, String statusCode, String accountNumber, String customerIdentifier,
			String createdByUserID, Instant createdTimestamp, Instant updatedTimestamp) {
		this.statusCode = statusCode;
		this.accountNumber = accountNumber;
		this.customerIdentifier = customerIdentifier;
		this.createdByUserID = createdByUserID;

	}

	public String getStatusCode() {
		return statusCode;
	}

	public void setStatusCode(String statusCode) {
		this.statusCode = statusCode;
	}

	public String getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}

	public String getCustomerIdentifier() {
		return customerIdentifier;
	}

	public void setCustomerIdentifier(String customerIdentifier) {
		this.customerIdentifier = customerIdentifier;
	}

	public String getCreatedByUserID() {
		return createdByUserID;
	}

	public void setCreatedByUserID(String createdByUserID) {
		this.createdByUserID = createdByUserID;
	}

	@Override
	public String toString() {
		return "CaseDetails{" + "statusCode='" + statusCode + '\'' + ", accountNumber='" + accountNumber + '\''
				+ ", customerIdentifier='" + customerIdentifier + '\'' + ", createdByUserID='" + createdByUserID + '\''
				+ '}';
	}
}
