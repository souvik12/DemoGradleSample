package com.barclays.bfams.kafka.consumer;

import java.util.Set;

import javax.validation.ConstraintViolation;
import javax.validation.Validation;
import javax.validation.Validator;
import javax.validation.ValidatorFactory;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.cloud.stream.annotation.StreamListener;
import org.springframework.kafka.support.KafkaHeaders;
import org.springframework.messaging.handler.annotation.Header;
import org.springframework.stereotype.Component;

import com.barclays.bfams.dto.CaseDetails;
import com.barclays.bfams.exception.DataValidationException;
import com.barclays.bfams.kafka.channel.StreamProcessor;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

@Component
public class KafkaListener {

	private static final Logger logger = LoggerFactory.getLogger(KafkaListener.class);

	@StreamListener(StreamProcessor.INPUT)
	public void messageListener(final CaseDetails payload, @Header(KafkaHeaders.CORRELATION_ID) String correlationID) {
		logger.info("CorrelationID " + correlationID);
		logger.info("Received message from topic " + payload);

		boolean validation = validation(payload);
		if(validation) {
			logger.error("Data Validation Error");
			throw new DataValidationException(createJsonString(payload));
		}
		
	}

	private String createJsonString(final CaseDetails payload) {
		// Java Object to Json.
		ObjectMapper mapper = new ObjectMapper();
		String jsonString = null;
		// Converting the Object to JSONString
		try {
			jsonString = mapper.writeValueAsString(payload);
		} catch (JsonProcessingException e1) {
			logger.error("Error while converting DTO to Json String" + e1.getMessage());
		}
		return jsonString;
	}

	private boolean validation(CaseDetails caseDetails) {
		// Create ValidatorFactory which returns validator
		ValidatorFactory factory = Validation.buildDefaultValidatorFactory();

		// It validates bean instances
		Validator validator = factory.getValidator();

		// Validate bean
		Set<ConstraintViolation<CaseDetails>> constraintViolations = validator.validate(caseDetails);
		boolean validationerror = false;
		// Show errors
		if (constraintViolations.size() > 0) {
			for (ConstraintViolation<CaseDetails> violation : constraintViolations) {
				logger.error(violation.getMessage());
			}
			validationerror = true;
		} else {
			logger.info("Valid Object");
		}
		return validationerror;

	}
}
