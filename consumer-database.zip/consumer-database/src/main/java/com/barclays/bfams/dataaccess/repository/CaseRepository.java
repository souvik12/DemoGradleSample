package com.barclays.bfams.dataaccess.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.barclays.bfams.dataaccess.entities.CaseEntity;

@Repository
public interface CaseRepository extends JpaRepository<CaseEntity, Long> {
	
}
