package com.barclays.bfams.kafka.consumer;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.stream.annotation.StreamListener;
import org.springframework.dao.DataAccessException;
import org.springframework.kafka.support.KafkaHeaders;
import org.springframework.messaging.handler.annotation.Header;
import org.springframework.stereotype.Component;

import com.barclays.bfams.dto.CaseCreateDetails;
import com.barclays.bfams.dto.CaseDetails;
import com.barclays.bfams.exception.BfadsException;
import com.barclays.bfams.kafka.channel.StreamProcessor;
import com.barclays.bfams.servicesimp.CaseOperation;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

@Component
public class KafkaListener {
	@Autowired
	CaseOperation caseOperation;
	private static final Logger logger = LoggerFactory.getLogger(KafkaListener.class);

	@StreamListener(StreamProcessor.INPUT)
	public void messageListener(final CaseDetails payload, @Header(KafkaHeaders.CORRELATION_ID) String correlationID) {
		logger.info("CorrelationID " + correlationID);
		logger.info("Received message from topic " + payload);

		CaseCreateDetails caseDetail = new CaseCreateDetails();
		caseDetail.setAccountNumber(payload.getAccountNumber());
		caseDetail.setCreatedByUserID(payload.getCreatedByUserID());
		caseDetail.setStatusCode(payload.getStatusCode());
		caseDetail.setCustomerIdentifier(payload.getCustomerIdentifier());
		try {

			CaseCreateDetails caseDet = caseOperation.caseCreate(caseDetail);
		} catch (DataAccessException e2) {
			logger.error("Data access error"+e2.getMessage());
			String jsonString = createJsonString(payload);
			throw new RuntimeException(jsonString);
		} catch (Exception e2) {
			logger.error("Data access error"+e2.getMessage());
			String jsonString = createJsonString(payload);
			throw new BfadsException(jsonString);
		}

	}

	

	private String createJsonString(final CaseDetails payload) {
		// Java Object to Json.
		ObjectMapper mapper = new ObjectMapper();
		String jsonString = null;
		// Converting the Object to JSONString
		try {
			jsonString = mapper.writeValueAsString(payload);
		} catch (JsonProcessingException e1) {

			e1.printStackTrace();
		}
		return jsonString;
	}

/*	@StreamListener("errorChannel")
	public void globalErrors(ErrorMessage message) {

		String payload = message.getPayload().getCause().getMessage();
		System.out.println("jsonString Payload " + payload);
		CaseDetails replayP = null;
		try {
			replayP = new ObjectMapper().readValue(payload, CaseDetails.class);
			System.out.println("replayP " + replayP);

		} catch (JsonParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (JsonMappingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}*/
}
