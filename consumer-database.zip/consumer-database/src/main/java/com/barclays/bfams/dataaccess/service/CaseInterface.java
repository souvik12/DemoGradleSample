package com.barclays.bfams.dataaccess.service;

import org.springframework.dao.DataAccessException;

import com.barclays.bfams.dto.CaseCreateDetails;

public interface CaseInterface {
    public CaseCreateDetails caseDetail(Long caseId) throws DataAccessException, Exception;
    public CaseCreateDetails caseCreate(CaseCreateDetails caseDetail) throws DataAccessException, Exception;
    public CaseCreateDetails caseUpdate(CaseCreateDetails caseDetail) throws DataAccessException, Exception;
    public void caseDelete(Long caseId) throws DataAccessException, Exception;
}

