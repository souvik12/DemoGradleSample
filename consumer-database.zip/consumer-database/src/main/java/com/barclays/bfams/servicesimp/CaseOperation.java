package com.barclays.bfams.servicesimp;

import java.time.Instant;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Component;

import com.barclays.bfams.dataaccess.entities.CaseEntity;
import com.barclays.bfams.dataaccess.repository.CaseRepository;
import com.barclays.bfams.dataaccess.service.CaseInterface;
import com.barclays.bfams.dto.CaseCreateDetails;
@Component
public class CaseOperation implements CaseInterface {


    CaseEntity caseEn;
    @Autowired
    CaseRepository caseRepo;
    CaseCreateDetails caseDet;

    @Override
    public CaseCreateDetails caseDetail(Long caseId) throws DataAccessException, Exception{
        CaseCreateDetails caseDet=null;
        try {
            Optional<CaseEntity> caseDetail =  caseRepo.findById(caseId);
                if(caseDetail.isPresent()){
                CaseEntity entity=caseDetail.get();
                 caseDet=new CaseCreateDetails(entity.getCaseId(),entity.getStatusCode(),entity.getAccountNumber(),entity.getCustomerIdentifier(),entity.getCreatedByUserID(),entity.getCreatedTimestamp(),entity.getUpdatedTimestamp());
            }

        } catch (DataAccessException e) {
           throw e;
        }catch (Exception e) {
            throw e;
        }
        return caseDet;
    }

    @Override
    public CaseCreateDetails caseCreate(CaseCreateDetails caseDetail) throws DataAccessException, Exception {
        CaseCreateDetails caseDet=null;
        try {
            caseEn = new CaseEntity();
            caseEn.setAccountNumber(caseDetail.getAccountNumber());
            caseEn.setCreatedByUserID(caseDetail.getCreatedByUserID());
            caseEn.setCustomerIdentifier(caseDetail.getCustomerIdentifier());
            caseEn.setStatusCode(caseDetail.getStatusCode());
            caseEn.setCreatedTimestamp(Instant.now());
            caseEn.setUpdatedTimestamp(Instant.now());
            CaseEntity  entity=  caseRepo.save(caseEn);
            caseDet=new CaseCreateDetails(entity.getCaseId(),entity.getStatusCode(),entity.getAccountNumber(),entity.getCustomerIdentifier(),entity.getCreatedByUserID(),entity.getCreatedTimestamp(),entity.getUpdatedTimestamp());
        } catch (DataAccessException e) {
            throw e;
        }catch (Exception e) {
            throw e;
        }
        return caseDet;
    }



    @Override
    public CaseCreateDetails caseUpdate(CaseCreateDetails caseDetail) throws DataAccessException, Exception{
        CaseCreateDetails caseDet=null;
        try {
            Optional<CaseEntity> caseDetails   = caseRepo.findById(caseDetail.getId());
           if(caseDetails.isPresent()) {
               CaseEntity existingDetails=caseDetails.get();
               caseEn = new CaseEntity();
               caseEn.setCaseId(caseDetail.getId());
               caseEn.setAccountNumber(caseDetail.getAccountNumber());
               caseEn.setCreatedByUserID(caseDetail.getCreatedByUserID());
               caseEn.setCustomerIdentifier(caseDetail.getCustomerIdentifier());
               caseEn.setStatusCode(caseDetail.getStatusCode());
               caseEn.setCreatedTimestamp(existingDetails.getCreatedTimestamp());
               caseEn.setUpdatedTimestamp(Instant.now());

               CaseEntity entity = caseRepo.save(caseEn);
               caseDet = new CaseCreateDetails(entity.getCaseId(), entity.getStatusCode(), entity.getAccountNumber(), entity.getCustomerIdentifier(), entity.getCreatedByUserID(), entity.getCreatedTimestamp(), entity.getUpdatedTimestamp());
           }
           } catch (DataAccessException e) {
            throw e;
        }catch (Exception e) {
            throw e;
        }
        return caseDet;
    }

    @Override
    public void caseDelete(Long caseId) throws DataAccessException, Exception {
        try {
            caseRepo.deleteById(caseId);


        } catch (DataAccessException e) {
            throw e;
        }catch (Exception e) {
            throw e;
        }

    }
}
