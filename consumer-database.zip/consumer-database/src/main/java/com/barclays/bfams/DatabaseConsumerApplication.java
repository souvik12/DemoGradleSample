package com.barclays.bfams;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.stream.annotation.EnableBinding;

import com.barclays.bfams.kafka.channel.StreamProcessor;

@SpringBootApplication
@EnableBinding(StreamProcessor.class)
public class DatabaseConsumerApplication{ 

	
	public static void main(String[] args) {
		SpringApplication.run(DatabaseConsumerApplication.class, args);
	}
	
}
