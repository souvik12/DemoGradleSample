package com.barclays.digital.spndcneng.contact;

import java.util.HashMap;
import java.util.Map;
import java.util.Random;

import com.barclays.digital.spndcneng.excpetion.SapiensException;

public class DetermineContactSteategy {
	
	
	public Map<String, Object> execute(Map<String, Object> customerMap){
		
		String key = (String) customerMap.get("customerNumber");
		Map<String, Object> response = new HashMap<String, Object>();
		String contactMethod = contactUtil(key);
		response.put("contactMethod", contactMethod);
		
		return response;
	
	}

	
	//Mock method to return the random response
	
	public String contactUtil(String key) {
		Map<Integer, String> contactMap = new HashMap<Integer, String>();
		contactMap.put(0, "eMail");
		contactMap.put(1, "SMS");
		contactMap.put(2, "Letter");
		contactMap.put(3, "Phone");
		Integer i = new Random().nextInt(contactMap.size());
		System.out.println("key "+i);
		return contactMap.get(i);
	
	}
	
	public Map<String, Object> executeContact(Map<String, Object> customerMap) throws SapiensException{
		
		if (customerMap.isEmpty()) {
			throw new SapiensException();
		}
		String key = (String) customerMap.get("customerNumber");
		Map<String, Object> response = new HashMap<String, Object>();
		String contactMethod = contactUtil(key);
		response.put("contactMethod", contactMethod);
		
		return response;
	
	}
}
