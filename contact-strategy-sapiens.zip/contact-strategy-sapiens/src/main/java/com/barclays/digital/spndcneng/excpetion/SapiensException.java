package com.barclays.digital.spndcneng.excpetion;

public class SapiensException extends RuntimeException{

	private static final long serialVersionUID = 1L;

}
