package com.barclays.digital.spndcneng.contact;

import java.util.HashMap;
import java.util.Map;

public class ContactApplication {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		DetermineContactSteategy contStrategy = new DetermineContactSteategy();
		Map<String, Object> response = new HashMap<String, Object>();
		Map<String, Object> input = new HashMap<String, Object>();
		input.put("customerNumber", "123");
		response = contStrategy.execute(input);
		System.out.println("response1 "+response.get("contactMethod"));
		response = contStrategy.execute(input);
		System.out.println("response2 "+response.get("contactMethod"));
		response = contStrategy.execute(input);
		System.out.println("response3 "+response.get("contactMethod"));
		
		Map<String, Object> customerMap = new HashMap<String, Object>();
		try {
		contStrategy.executeContact(customerMap);
		} catch(Exception e) {
			e.printStackTrace();
		}
	}

}
