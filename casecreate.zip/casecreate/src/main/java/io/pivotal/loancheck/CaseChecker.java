package io.pivotal.loancheck;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.stream.annotation.StreamListener;
import org.springframework.messaging.Message;
import org.springframework.messaging.support.MessageBuilder;
import org.springframework.stereotype.Component;

@Component
public class CaseChecker {

  public static final Logger log = LoggerFactory.getLogger(CaseChecker.class);
  private CaseProcessor processor;

  @Autowired
  public CaseChecker(CaseProcessor processor) {
    this.processor = processor;
  }

  @StreamListener(CaseProcessor.APPLICATIONS_IN)
  public void checkAndSortLoans(Case casedata) {
    log.info("{} {} for ${} for {}", casedata.getStatus(), casedata.getUuid(), casedata.getName());

    if (casedata.getName().equalsIgnoreCase("Donald")) {
      casedata.setStatus(Statuses.DECLINED.name());
      processor.declined().send(message(casedata));
    } else {
      casedata.setStatus(Statuses.APPROVED.name());
      processor.approved().send(message(casedata));
    }

    log.info("{} {} for ${} for {}", casedata.getStatus(), casedata.getUuid(), casedata.getName());

  }

  private static final <T> Message<T> message(T val) {
    return MessageBuilder.withPayload(val).build();
  }
}
