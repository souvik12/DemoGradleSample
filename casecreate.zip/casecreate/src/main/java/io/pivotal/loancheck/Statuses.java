package io.pivotal.loancheck;

public enum Statuses {
  APPROVED, DECLINED, PENDING, REJECTED
}
