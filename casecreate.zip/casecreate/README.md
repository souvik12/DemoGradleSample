# Loan Checker Service

Receives applications via messaging and then sorts them into Approved and Declined
