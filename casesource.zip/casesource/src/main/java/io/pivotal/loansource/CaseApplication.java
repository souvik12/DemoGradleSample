package io.pivotal.loansource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import java.util.Arrays;
import java.util.List;
import java.util.Random;
import java.util.UUID;
import java.util.function.Supplier;

@SpringBootApplication
public class CaseApplication {

  private static final Logger log = LoggerFactory.getLogger(CaseApplication.class);
  private List<String> names = Arrays.asList("Donald", "Theresa", "Vladimir", "Angela", "Emmanuel", "Shinzō", "Jacinda",
      "Kim");

  public static void main(String[] args) {
    SpringApplication.run(CaseApplication.class, args);
    log.info("The Customer Case Source Application has started...");
  }

  @Bean
  public Supplier<CaseData> supplyLoan() {
    return () -> {
      String rName = names.get(new Random().nextInt(names.size()));
      CaseData caseData = new CaseData(UUID.randomUUID().toString(),rName);
      log.info("{} {} for ${} for {}", caseData.getStatus(), caseData.getUuid(), caseData.getName());
      return caseData;
    };
  }

  
}
