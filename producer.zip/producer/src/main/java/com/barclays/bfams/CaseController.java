package com.barclays.bfams;

import java.time.Instant;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.barclays.bfams.dto.CaseDetail;
import com.barclays.bfams.kafka.producer.KafkaPublisher;

@RestController
public class CaseController {

   @Autowired
   KafkaPublisher kafkaPublisher;

       @PostMapping (path = "/caseCreate",  consumes = MediaType.APPLICATION_JSON_VALUE)
       public void handleRequest(@RequestBody CaseDetail  body) {
    	   body.setTimestamp(Instant.now().toString());
           kafkaPublisher.MessagePublisher(body);

    }

}
