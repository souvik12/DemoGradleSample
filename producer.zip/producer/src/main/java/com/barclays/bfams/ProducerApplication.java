package com.barclays.bfams;

import java.time.Instant;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.stream.annotation.EnableBinding;

import com.barclays.bfams.dto.CaseDetail;
import com.barclays.bfams.kafka.channel.StreamProcessor;
import com.barclays.bfams.kafka.producer.KafkaPublisher;

@SpringBootApplication
@EnableBinding(StreamProcessor.class)
public class ProducerApplication implements CommandLineRunner {
	@Autowired
	KafkaPublisher kafkaPublisher;

	public static void main(String[] args) {
		SpringApplication.run(ProducerApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		final long timeInterval = 20000;
		CaseDetail payloadDetail = new CaseDetail();
		payloadDetail.setMessage("Case Created");
		payloadDetail.setTimestamp(Instant.now().toString());
		while (true) {

			try {
				kafkaPublisher.MessagePublisher(payloadDetail);
				Thread.sleep(timeInterval);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}

}
