package com.barclays.bfams.kafka.producer;


import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.support.KafkaHeaders;
import org.springframework.messaging.Message;
import org.springframework.messaging.support.MessageBuilder;
import org.springframework.stereotype.Component;

import com.barclays.bfams.kafka.channel.StreamProcessor;

@Component
public class KafkaPublisher {
    @Autowired
    StreamProcessor messageChannel;

    public  <T> void MessagePublisher(T payloadDetail) {
    	
        messageChannel.outboundStreams().send(message(payloadDetail));
    }
    private static final <T> Message<T> message(T payload) {
    	
    	
        return MessageBuilder.withPayload(payload).setHeader(KafkaHeaders.CORRELATION_ID, UUID.randomUUID().toString()).build();

        
    }

}
