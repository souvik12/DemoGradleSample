package com.example.demo;

import static org.junit.jupiter.api.Assertions.assertEquals;

import com.example.demo.querygateway.dao.Eventlog;
import com.example.demo.querygateway.dao.EventlogRepository;
import java.util.Optional;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EventlogRepositoryTest {
  @Autowired
  EventlogRepository eventlogRepository;
  @Test
  void findById() {
    Optional<Eventlog> all=eventlogRepository.findById(1);
    // System.out.println(all.get().getCustnumber());
    assertEquals("45caffb5-28e5-4344-8d76-dd1fd037a2fa",all.get().getCorelationid());
  }
}