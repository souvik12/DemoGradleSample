package com.example.demo.service;

import lombok.Data;

@Data
public class CustmerEmailSendStatus {

  private String custNo;
  private String emailSentStatus;
}
