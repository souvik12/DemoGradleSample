package com.example.demo;

import com.example.demo.commandgateway.BfaOutputProcessor;
import com.example.demo.streamlistener.BfaInputProcessor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.stream.annotation.EnableBinding;

@SpringBootApplication
@EnableBinding({BfaInputProcessor.class, BfaOutputProcessor.class})
public class CaseApplication {

  public static final Logger log = LoggerFactory.getLogger(CaseApplication.class);

  public static void main(String[] args) {
    SpringApplication.run(CaseApplication.class, args);
  }

}



