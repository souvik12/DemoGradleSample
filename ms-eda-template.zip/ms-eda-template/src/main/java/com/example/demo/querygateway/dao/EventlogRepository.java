package com.example.demo.querygateway.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

public interface EventlogRepository extends JpaRepository<Eventlog, Integer>, JpaSpecificationExecutor<Eventlog> {

}