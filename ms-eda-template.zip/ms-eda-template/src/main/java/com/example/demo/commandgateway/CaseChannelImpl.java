package com.example.demo.commandgateway;

import com.example.demo.CaseApplication;
import com.example.demo.streamlistener.CaseData;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.integration.support.MessageBuilder;
import org.springframework.messaging.Message;
import org.springframework.messaging.MessageHeaders;
import org.springframework.stereotype.Component;

@Component
public class CaseChannelImpl implements CaseChannel {
  public static final Logger log = LoggerFactory.getLogger(CaseApplication.class);
  private final BfaOutputProcessor bfaOutputProcessor;

  public CaseChannelImpl(BfaOutputProcessor bfaOutputProcessor) {
    this.bfaOutputProcessor = bfaOutputProcessor;
  }

  @Override
  public void process(CaseData caseData, MessageHeaders headers) {
    log.info("{} {} for ${} for {}", caseData.toString());
    log.info("{} {} for ${} for {}", caseData.toString());
    bfaOutputProcessor.bfaoutput().send(message(caseData));
  }

  private static final <T> Message<T> message(T val) {
    return MessageBuilder.withPayload(val).build();
  }
}
