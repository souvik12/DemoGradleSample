package com.example.demo.service;

import com.example.demo.commandgateway.CaseChannel;
import com.example.demo.exception.DuplicateAccountIdException;
import com.example.demo.querygateway.dao.Eventlog;
import com.example.demo.querygateway.dao.EventlogRepository;
import com.example.demo.streamlistener.CaseData;
import java.util.Optional;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.messaging.MessageHeaders;
import org.springframework.stereotype.Component;


@Component
public class CaseServiceImpl implements CaseService {

  public static final Logger log = LoggerFactory.getLogger(CaseServiceImpl.class);

  private final EventlogRepository eventlogRepository;
  private final CaseChannel caseChannel;

  public CaseServiceImpl(EventlogRepository eventlogRepository, CaseChannel caseChannel) {
    this.eventlogRepository = eventlogRepository;
    this.caseChannel = caseChannel;
  }

  @Override
  public void service(CaseData caseData, MessageHeaders headers) throws DuplicateAccountIdException {
    boolean eventLogExistenenceStatus = getEventLogStatus(caseData);
    log.info("{} {} for ${} for {}", caseData.toString());
    log.info("{} {} for ${} for {}", headers.toString());
    if ((eventLogExistenenceStatus == true)) {
      caseChannel.process(caseData, headers);
      log.info("{} {} for ${} for {}", caseData.toString());
      log.info("{} {} for ${} for {}", headers.toString());
    }

  }


  private boolean getEventLogStatus(CaseData caseData) throws DuplicateAccountIdException {
    Optional<Eventlog> eventlog = eventlogRepository.findById(caseData.getAccountid());
    if (eventlog.isPresent()) {
      throw new DuplicateAccountIdException("Duplicate request has been reported");
    } else {
      return true;
    }
  }


}
