package com.example.demo.commandgateway;

import org.springframework.cloud.stream.annotation.Output;
import org.springframework.messaging.MessageChannel;

public interface BfaOutputProcessor {

  String bfaoutput = "bfaoutput";

  @Output(bfaoutput)
  MessageChannel bfaoutput();


}

