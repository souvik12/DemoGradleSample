package com.example.demo.streamlistener;

import org.springframework.cloud.stream.annotation.Input;
import org.springframework.messaging.SubscribableChannel;

public interface BfaInputProcessor {

  String bfainput = "bfainput";

  @Input(bfainput)
  SubscribableChannel bfainput();
}

