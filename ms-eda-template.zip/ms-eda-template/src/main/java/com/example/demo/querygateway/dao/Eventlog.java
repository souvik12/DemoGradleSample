package com.example.demo.querygateway.dao;

import java.io.Serializable;
import java.sql.Timestamp;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import lombok.Data;


@Table(name = "eventlog")
@Data
@Entity
public class Eventlog implements Serializable {
  private static final long serialVersionUID = 1L;

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  @Column(name = "id", insertable = false, nullable = false)
  private Integer id;

  @Column(name = "corelationid")
  private String corelationid;

  @Column(name = "eventid")
  private String eventid;

  @Column(name = "eventsource")
  private String eventsource;

  @Column(name = "eventtype")
  private String eventtype;

  @Column(name = "createtime", nullable = false)
  private Timestamp createtime;

  @Column(name = "payload")
  private byte[] payload;

  @Column(name = "eventsequence", nullable = false)
  private Integer eventsequence;

  @Column(name = "metadata")
  private byte[] metadata;

  
}