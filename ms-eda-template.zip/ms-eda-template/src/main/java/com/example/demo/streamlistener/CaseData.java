package com.example.demo.streamlistener;

import javax.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class CaseData {

  private int custid;
  private int accountid;
  private String accountNumber;
  @Size(max = 10, min = 4, message = "Customer Number Invalid")
  private String custNo;
}