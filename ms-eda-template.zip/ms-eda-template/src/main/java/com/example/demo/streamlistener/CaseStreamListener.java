package com.example.demo.streamlistener;

import com.example.demo.CaseApplication;
import com.example.demo.exception.DuplicateAccountIdException;
import com.example.demo.service.CaseService;
import javax.validation.Valid;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.cloud.stream.annotation.StreamListener;
import org.springframework.messaging.MessageHeaders;
import org.springframework.stereotype.Component;

@Component
public class CaseStreamListener {

  public static final Logger log = LoggerFactory.getLogger(CaseApplication.class);
  private final CaseService caseService;

  public CaseStreamListener(CaseService caseService) {
    this.caseService = caseService;
  }

  @StreamListener(BfaInputProcessor.bfainput)
  public void applyCaseStrategy(@Valid CaseData caseData, MessageHeaders messageHeaders) throws DuplicateAccountIdException {

    log.info("{} {} for ${} for {}", "BFA_UK_COLLECTIONS_CONTACTSTRATEGY_CONTACTDECIDED");
    log.info("{} {} for ${} for {}", caseData.toString());
    log.info("{} {} for ${} for {}", caseData.toString());
    caseService.service(caseData, messageHeaders);
  }
}
