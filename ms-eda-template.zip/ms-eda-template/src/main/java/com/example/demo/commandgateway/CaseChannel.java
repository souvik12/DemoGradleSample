package com.example.demo.commandgateway;

import com.example.demo.streamlistener.CaseData;
import org.springframework.messaging.MessageHeaders;

public interface CaseChannel {

  void process(CaseData caseData, MessageHeaders headers);
}
