package com.example.demo.exception;

public class DuplicateAccountIdException extends Throwable {
  public DuplicateAccountIdException(String message) {
    super(message);
  }
}
