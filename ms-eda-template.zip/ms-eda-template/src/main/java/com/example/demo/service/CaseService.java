package com.example.demo.service;

import com.example.demo.exception.DuplicateAccountIdException;
import com.example.demo.streamlistener.CaseData;
import org.springframework.messaging.MessageHeaders;

public interface CaseService {

  void service(CaseData caseData, MessageHeaders headers) throws DuplicateAccountIdException;
}
